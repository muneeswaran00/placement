
#include <stdio.h>

int main()
{
    int a,b,c,triangle;
    printf("enter three numbers:");
    scanf("%d %d %d",&a,&b,&c);
   
    ((a==b&&b==c && a+b>c)?printf("equ triangle is possible"):printf("equ triangle is not possible"));

    return 0;
}
